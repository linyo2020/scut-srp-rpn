#include "petritabwidget.h"

PetriTabWidget::PetriTabWidget(QWidget *parent) : QWidget(parent)
{

}
